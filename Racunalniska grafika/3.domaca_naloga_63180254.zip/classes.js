 class QuadTree {
     constructor(kvadrat) {
         this.kvadrat = kvadrat;
         this.tocke = [];
         this.razdeljen = false;
     }
     dodaj(tocka) {
         if (!this.kvadrat.contains(tocka)) { //Ce ne vsebuje tocke, ne stori nic
             return;
         } else {
             if (!this.razdeljen) { //Ce se ni razdeljen
                 if (this.tocke.length < 4) {
                     this.tocke.push(tocka);
                 } else { //Ce ze vsebuje 4 tocke, ustvari poddrevesa in dodaj tocke v poddrevesa
                     this.razdeliQT();
                     for (var i = 0; i < 4; i++) { //Dodamo tocke v poddrevesa
                         this.qtreeZL.dodaj(this.tocke[i]);
                         this.qtreeZD.dodaj(this.tocke[i]);
                         this.qtreeSL.dodaj(this.tocke[i]);
                         this.qtreeSD.dodaj(this.tocke[i]);
                     }
                     //Odstranimo tocke iz trenutnega drevesa
                     this.tocke.pop();
                     this.tocke.pop();
                     this.tocke.pop();
                     this.tocke.pop();
                 }
             } else {
                 this.qtreeZL.dodaj(tocka);
                 this.qtreeZD.dodaj(tocka);
                 this.qtreeSL.dodaj(tocka);
                 this.qtreeSD.dodaj(tocka);
             }
         }
     }
     razdeliQT() {
         let x = this.kvadrat.x;
         let y = this.kvadrat.y;
         let w = this.kvadrat.w / 2;
         let h = this.kvadrat.h / 2;
         this.qtreeZL = new QuadTree(new Rectangle(x - w, y - h, w, h));
         this.qtreeZD = new QuadTree(new Rectangle(x + w, y - h, w, h));
         this.qtreeSL = new QuadTree(new Rectangle(x - w, y + h, w, h));
         this.qtreeSD = new QuadTree(new Rectangle(x + w, y + h, w, h));
         this.razdeljen = true;
     }
     prekrivanje() {
         for (var i = 0; i < this.tocke.length; i++) {
             this.tocke[i].oznaci = false;
             for (var j = 0; j < this.tocke.length; j++) {
                 sttree++;
                 if (i != j && this.tocke[i].prekrivanje(this.tocke[j])) {
                     this.tocke[i].oznaci = true;
                     trki++;
                 }
             }
         }
         if (this.razdeljen) {
             this.qtreeSD.prekrivanje();
             this.qtreeSL.prekrivanje();
             this.qtreeZD.prekrivanje();
             this.qtreeZL.prekrivanje();
         }

     }

     narisi(ctx) {
         ctx.beginPath();
         ctx.rect(this.kvadrat.x - this.kvadrat.w, this.kvadrat.y - this.kvadrat.h, this.kvadrat.w * 2, this.kvadrat.h * 2);
         ctx.stroke();
         if (this.razdeljen) {
             this.qtreeZL.narisi(ctx);
             this.qtreeZD.narisi(ctx);
             this.qtreeSL.narisi(ctx);
             this.qtreeSD.narisi(ctx);
         }

     }
 }

 class Point {
     constructor(x, y) {
         this.x = x;
         this.y = y;
         this.dx = Math.floor(Math.random() * (2 - -2 + 1)) + -2;
         if (this.dx == 0) { this.dx = -1; }
         this.dy = Math.floor(Math.random() * (2 - -2 + 1)) + -2;
         if (this.dy == 0) { this.dy = 1; }
         this.oznaci = false;
     }
     narisi(ctx) {
         ctx.beginPath();
         if (this.oznaci) {
             ctx.strokeStyle = "red";
             ctx.fillStyle = "red";
         } else {
             ctx.strokeStyle = "black";
             ctx.fillStyle = "black";
         }
         ctx.arc(this.x, this.y, 5, 0, 2 * Math.PI);
         ctx.fill();
         ctx.stroke();
         ctx.strokeStyle = "black";
     }
     prekrivanje(tocka) {
         if (
             this.x - 10 < tocka.x &&
             this.x + 10 > tocka.x &&
             this.y - 10 < tocka.y &&
             this.y + 10 > tocka.y
         ) {
             return true;
         } else {
             return false;
         }
     }
     premikaj() {
         if (this.x + this.dx < 0 || this.x + this.dx > sirina) {
             this.dx *= -1;
         } else if (this.y + this.dy < 0 || this.y + this.dy > visina) {
             this.dy *= -1;
         }
         this.x += this.dx;
         this.y += this.dy;
     }
 }
 class Rectangle {
     constructor(x, y, w, h) {
         this.x = x;
         this.y = y;
         this.w = w;
         this.h = h;
     }
     contains(tocka) {
         if (tocka.x >= this.x - this.w &&
             tocka.x <= this.x + this.w &&
             tocka.y >= this.y - this.h &&
             tocka.y <= this.y + this.h) {
             return true;
         } else {
             return false;
         }
     }
     presek(predmet) {
         if (predmet.x - predmet.w > this.x + this.w ||
             predmet.x + predmet.w < this.x - this.w ||
             predmet.y - predmet.h > this.y + this.h ||
             predmet.y + predmet.h < this.y - this.h) {
             return false;
         } else {
             return true;
         }
     }
 }
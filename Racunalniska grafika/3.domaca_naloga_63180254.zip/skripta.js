let tocke = [];
let trki = 0;
let sttree = 0;
let sirina = window.innerHeight;
let visina = window.innerHeight - 20;
let okno = new Rectangle(sirina, visina, sirina, visina);
let c = document.getElementById("myCanvas");
let ctx = c.getContext("2d");
c.width = sirina;
c.height = visina;

for (var i = 0; i < 10; i++) {
    tocke.push(new Point(Math.random() * sirina, Math.random() * visina));
}
document.getElementById("st").value = 10;
document.getElementById("st").oninput = function() {
    spremeniStevilo();
};

function spremeniStevilo() {
    let st = document.getElementById("st").value;
    if (st > 9999) {
        document.getElementById("st").value = 9999;
        st = 9999;
    }
    if (st < 1) {
        document.getElementById("st").value = 1;
        st = 1;
    }
    if (st > tocke.length) {
        while (tocke.length < st) {
            tocke.push(new Point(Math.random() * sirina, Math.random() * visina));
        }
    } else {
        while (tocke.length > st) {
            tocke.pop();
        }
    }
}


function draw() {
    let zacetek = Date.now();
    trki = 0;
    sttree = 0;
    let mreza = document.getElementById("stikalo").checked;
    ctx.clearRect(0, 0, sirina, visina);
    let qt = new QuadTree(okno);
    for (var i = 0; i < tocke.length; i++) {
        tocke[i].premikaj();
    }
    for (var i = 0; i < tocke.length; i++) {
        qt.dodaj(tocke[i]);
    }
    qt.prekrivanje();
    for (var i = 0; i < tocke.length; i++) {
        tocke[i].narisi(ctx);
    }

    if (mreza) {
        qt.narisi(ctx);
    }
    let brute = Math.pow(tocke.length, 2);
    let izboljsava = Math.round(brute / sttree);
    let konec = Date.now();
    let fps = Math.round(1000 / (konec - zacetek));
    if (fps > 1000) {
        fps = 1000;
    }


    document.getElementById("brute").innerHTML = brute;
    document.getElementById("trki").innerHTML = trki;
    document.getElementById("tree").innerHTML = sttree;
    document.getElementById("izboljsava").innerHTML = izboljsava + "x";
    document.getElementById("fps").innerHTML = fps;

    window.requestAnimationFrame(draw);
}
window.requestAnimationFrame(draw);
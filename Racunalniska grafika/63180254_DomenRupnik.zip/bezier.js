class Krivulja {
    constructor() {
        this.tocke = [];
        this.tockeBern = [];
        this.korak = 0.01;
        this.bernsteinova_matrika = [
            [1, 0, 0, 0],
            [-3, 3, 0, 0],
            [3, -6, 3, 0],
            [-1, 3, -3, 1]
        ];
        this.debelina = 1;
        this.barva = "#000000";
        this.izracunane_tocke = [];
        this.izbrana = false;
    }

    //Narisemo krivuljo, glede na tocke v tabeli izracunane_tocke
    narisi() {
        ctx.lineWidth = this.debelina;
        for (var i = 0; i < this.izracunane_tocke.length - 1; i++) {
            ctx.strokeStyle = this.barva;
            ctx.moveTo(this.izracunane_tocke[i][0], this.izracunane_tocke[i][1]);
            ctx.lineTo(this.izracunane_tocke[i + 1][0], this.izracunane_tocke[i + 1][1]);
            ctx.stroke();
        }
        ctx.lineWidth = 1;
    }

    //Izracunamo tocke, med katerimi nato potegnemo crte
    izracunajTocke() {
        this.izracunane_tocke = [];
        var t, t2, t3;
        var i = 0;
        this.korak = 0.02;
        while (i < 1) {
            t = i;
            t2 = Math.pow(i, 2);
            t3 = Math.pow(i, 3);
            var vek = this.zmnoziBernSTockami([1, t, t2, t3]);
            if (this.izracunane_tocke.length > 1) {
                if (Math.abs(vek[0] - this.izracunane_tocke[this.izracunane_tocke.length - 1][0]) > 2 || Math.abs(vek[1] - this.izracunane_tocke[this.izracunane_tocke.length - 1][1]) > 2) {
                    i -= this.korak;
                    this.korak *= 0.8;
                    continue;
                } else if (this.korak < 0.02) {
                    this.korak *= 1.01
                }
            }
            this.izracunane_tocke[this.izracunane_tocke.length] = vek;
            i += this.korak;
        }
        this.izracunane_tocke[this.izracunane_tocke.length] = this.tocke[3];
    }

    izracunajPreview() {
        this.izracunane_tocke = [];
        var t, t2, t3;
        var i = 0;
        this.korak = 0.05;
        while (i < 1) {
            t = i;
            t2 = Math.pow(i, 2);
            t3 = Math.pow(i, 3);
            var vek = this.zmnoziBernSTockami([1, t, t2, t3]);
            this.izracunane_tocke[this.izracunane_tocke.length] = vek;
            i += this.korak;
        }
        this.izracunane_tocke[this.izracunane_tocke.length] = this.tocke[3];
    }

    //Pomnozimo tockeBern s parametrom T (korak)
    zmnoziBernSTockami(vk) {
        var zm = [0, 0];
        for (var j = 0; j < 2; j++) {
            for (var i = 0; i < 4; i++) {
                zm[j] += this.tockeBern[i][j] * vk[i];
            }
        }
        return zm;
    }

    //Narisemo vozlisca
    narisiVozlisca() {
        for (var h = 0; h < this.tocke.length; h++) {
            if ((h + 1) % 4 == 1) {
                ctx.beginPath();
                ctx.rect(this.tocke[h][0], this.tocke[h][1], 5, 5);
                ctx.stroke();
            }
            if ((h + 1) % 4 == 2) {
                if (this.dolzina() > 1) {
                    ctx.beginPath();
                    ctx.strokeStyle = "green";
                    ctx.arc(this.tocke[h][0], this.tocke[h][1], 5, 0, 2 * Math.PI);
                    ctx.moveTo(this.tocke[0][0], this.tocke[0][1]);
                    ctx.lineTo(this.tocke[1][0], this.tocke[1][1]);
                    ctx.stroke();
                } else {
                    ctx.beginPath();
                    ctx.strokeStyle = "green";
                    ctx.arc(this.tocke[h][0], this.tocke[h][1], 5, 0, 2 * Math.PI);
                    ctx.stroke();
                }


            }
            if ((h + 1) % 4 == 3) {
                if (this.dolzina() > 3) {
                    ctx.beginPath();
                    ctx.strokeStyle = "green";
                    ctx.arc(this.tocke[h][0], this.tocke[h][1], 5, 0, 2 * Math.PI);
                    ctx.moveTo(this.tocke[3][0], this.tocke[3][1]);
                    ctx.lineTo(this.tocke[2][0], this.tocke[2][1]);
                    ctx.stroke();
                } else {
                    ctx.beginPath();
                    ctx.strokeStyle = "green";
                    ctx.arc(this.tocke[h][0], this.tocke[h][1], 5, 0, 2 * Math.PI);
                    ctx.stroke();
                }


            }
            if ((h + 1) % 4 == 0) {
                ctx.beginPath();
                ctx.fillStyle = "black";
                ctx.rect(this.tocke[h][0], this.tocke[h][1], 5, 5);
                ctx.stroke();
            }
        }
    }

    //Zmnozimo tocke z Bernsteinovo matriko
    xBern() {
        this.tockeBern = [
            [0, 0],
            [0, 0],
            [0, 0],
            [0, 0]
        ];
        var ses = 0;
        var h, i, j;
        for (h = 0; h < 4; h++) {
            for (i = 0; i < 2; i++) {
                for (j = 0; j < 4; j++) {
                    ses += this.tocke[j][i] * this.bernsteinova_matrika[h][j];
                }
                this.tockeBern[h][i] = ses;
                ses = 0;
            }
        }
    }

    //Dodamo tocke v tabelo tocke
    dodajVozlise(points) {
        this.tocke[this.tocke.length] = points;
    }

    //Vrnemo dolzino tabele tocke
    dolzina() {
        return this.tocke.length;
    }

    popraviTocke
        (index, xy) {
            this.tocke[index] = xy;
            this.xBern();
            this.izracunajTocke();

        }

    popraviTockePreview(index, xy) {
        this.tocke[index] = xy;
        this.xBern();
        this.izracunajPreview();

    }

}

//Pritisk miske
function mouseDown(e) {
    if (krivulje.length == 0) {
        krivulje[0] = new Krivulja();
    }
    if (e.x > 150) {
        if (!pogoj) {
            if (krivulje[krivulje.length - 1].dolzina() <= 4) {
                krivulje[krivulje.length - 1].dodajVozlise([e.x, e.y]);
                krivulje[krivulje.length - 1].narisiVozlisca();
            }
            if (krivulje[krivulje.length - 1].dolzina() == 4) {
                krivulje[krivulje.length - 1].xBern();
                krivulje[krivulje.length - 1].izracunajTocke();
                krivulje[krivulje.length - 1].narisi();
                krivulje[krivulje.length] = new Krivulja();
                krivulje[krivulje.length - 1].dodajVozlise([e.x, e.y]);
                krivulje[krivulje.length - 1].narisiVozlisca();
                dodajControl(false);

            }
        }
    }

}

//Dodamo aproksimirano tocko, čez zadnjo interpolirano
function dodajControl(pog) {
    if (pog) {
        //Ce spreminjamo krivvulje
        var vozlisce = krivulje[indexi].tocke[3];
        var predhodno_vozlisce = krivulje[indexi].tocke[2];
        var x1 = vozlisce[0] - predhodno_vozlisce[0];
        var y1 = vozlisce[1] - predhodno_vozlisce[1];
        x1 *= -1;
        y1 *= -1;
        //Ce smo zbrisali krivulje, nastavimo novi dve vozliši, da lahko nadaljujemo z risanjem
        if (krivulje.length == indexi + 1) {
            krivulje[krivulje.length] = new Krivulja();
            console.log(krivulje.length);
            krivulje[krivulje.length - 1].dodajVozlise(krivulje[krivulje.length - 2].tocke[3]);
            krivulje[krivulje.length - 1].dodajVozlise(krivulje[krivulje.length - 2].tocke[3]);

        }
        krivulje[indexi + 1].tocke[1] = [vozlisce[0] - x1, vozlisce[1] - y1];
        krivulje[indexi + 1].narisiVozlisca();
    }
    //Ce risemo novo krivuljo
    else {
        var vozlisce = krivulje[krivulje.length - 2].tocke[3];
        var predhodno_vozlisce = krivulje[krivulje.length - 2].tocke[2];
        var x1 = vozlisce[0] - predhodno_vozlisce[0];
        var y1 = vozlisce[1] - predhodno_vozlisce[1];
        x1 *= -1;
        y1 *= -1;
        krivulje[krivulje.length - 1].dodajVozlise([vozlisce[0] - x1, vozlisce[1] - y1]);
        krivulje[krivulje.length - 1].narisiVozlisca();
    }


}

//Pogledamo, če pritisnemo ustrezno vozlišče
function pritisk(e) {

    if (krivulje.length > 1) {
        for (var i = 0; i < krivulje.length - 1; i++) {
            if (i > 0 && i < krivulje.length) {
                for (var j = 0; j < krivulje[i].dolzina(); j++) {
                    if (e.x >= krivulje[i].tocke[j][0] - 5 && e.x <= krivulje[i].tocke[j][0] + 5 && e.y >= krivulje[i].tocke[j][1] - 5 && e.y <= krivulje[i].tocke[j][1] + 5) {
                        pogoj = true;
                        indexi = i;
                        indexj = j;
                        break;
                    }
                }
            } else if (i == 0) {
                for (var j = 1; j < krivulje[i].dolzina(); j++) {
                    if (e.x >= krivulje[i].tocke[j][0] - 5 && e.x <= krivulje[i].tocke[j][0] + 5 && e.y >= krivulje[i].tocke[j][1] - 5 && e.y <= krivulje[i].tocke[j][1] + 5) {
                        pogoj = true;
                        indexi = i;
                        indexj = j;
                        break;
                    }
                }
            }
        }


    }
    //Ne risemo in ne posodabljamo krivulj v levih 150pikslih
    if (e.x > 150) {
        var array = [];
        for (var a = 0; a < krivulje.length; a++) {
            if (krivulje[a].dolzina() >= 3) {
                array[a] = a + 1;
            }

        }
        //Zgeneriramo SELECT
        var besedilo = "<select id='mySelect'>";
        for (var i = 0; i < array.length; i++) {
            var ab = i + 1;
            besedilo += "<option value = '" + i + "'>" + ab + "</option> \n"
        }
        besedilo += "</select>";
        document.getElementById("mySelect").innerHTML = besedilo;
    }


}

function dvig_miske(e) {
    if (pogoj) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        krivulje[indexi].popraviTocke(indexj, [e.x, e.y]);
        if (indexi == krivulje.length - 2) {
            dodajControl(true);
        }



        for (var i = 0; i < krivulje.length; i++) {
            krivulje[i].narisiVozlisca();
            krivulje[i].narisi();
        }
    }

    pogoj = false;
}

function move(e) {
    if (pogoj) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        krivulje[indexi].popraviTockePreview(indexj, [e.x, e.y]);
        for (var i = 0; i < krivulje.length; i++) {
            krivulje[i].narisiVozlisca();
            krivulje[i].narisi();
        }
        if (indexi == krivulje.length - 2) {
            dodajControl(true);
        }
    }
}

//Ponovni izris celotnega canvasa
function ponovnoIzrisi() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    for (var i = 0; i < krivulje.length; i++) {
        krivulje[i].narisiVozlisca();
        krivulje[i].narisi();
    }
}

//Brisemo krivulje
function izbrisi() {
    izbran = document.getElementById("mySelect").value;
    krivulje.length = izbran;
    izbran = parseInt(izbran);
    indexi = izbran - 1;
    if (izbran != 0) {
        dodajControl(true);
    }
    ponovnoIzrisi();
    osveziSelect();


}

//Osvezujemo select, da lahko izberemo le krivulje, ki so na canvasu
function osveziSelect() {
    var array = [];
    for (var a = 0; a < krivulje.length; a++) {
        if (krivulje[a].dolzina() >= 3) {
            array[a] = a + 1;
        }

    }
    var besedilo = "<select id='mySelect'>";
    for (var i = 0; i < array.length; i++) {
        var ab = i + 1;
        besedilo += "<option value = '" + i + "'>" + ab + "</option> \n"
    }
    besedilo += "</select>";
    document.getElementById("mySelect").innerHTML = besedilo;
}
//Spreminjanje debeline črte
function spremeniDebelino() {
    krivulje[izbran].debelina = document.getElementById("myRange").value;
    ponovnoIzrisi();
}
//Spreminjanje barve črte
function spremeniBarvo() {
    krivulje[izbran].barva = document.getElementById("myColor").value;
    ponovnoIzrisi();
}
//Nastavimo izbrano črto
function nastaviIzbranega() {
    izbran = document.getElementById("mySelect").value;
    //Nastavimo parametre za barvo in debelino črte nazaj na kolikor so bile prej
    document.getElementById("myColor").value = krivulje[izbran].barva;
    document.getElementById("myRange").value = krivulje[izbran].debelina;

}

var canvas = document.getElementById("myCanvas");
var ctx = this.canvas.getContext("2d");
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;
//V krivulje hranimo objekte tipa Krivulja
var krivulje = [];
krivulje[0] = new Krivulja();
var prej = 0;
var izbran = 0;
var pogoj = false;
var indexi = 0;
var indexj = 0;

window.addEventListener('mousedown', function(e) {
    pritisk(e);
    mouseDown(e);
});
window.addEventListener('mousemove', function(e) {
    move(e);
});
window.addEventListener('mouseup', function(e) {
    dvig_miske(e);
});
document.getElementById("myRange").onchange = function() { spremeniDebelino() };
document.getElementById("myColor").onchange = function() { spremeniBarvo() };